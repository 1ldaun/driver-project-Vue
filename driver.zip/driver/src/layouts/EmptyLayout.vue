<template>
  <div class="empty-layout">
    <router-view />
  </div>
</template>
