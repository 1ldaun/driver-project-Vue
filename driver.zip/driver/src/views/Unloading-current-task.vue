<template>
<div class="unloading-current-task">
  <div class="header">
    <img class="header-logo" src="../assets/logo.jpg" alt="">
    <h1 class="header-h1">ТЕКУЩАЯ ЗАДАЧА:</h1>
  </div>

    <div>
      <h2 class="unloading-current-task-h2">Выгрузка:</h2>
      <h2 class="unloading-current-task-h3"><strong class="unloading-current-task-strong">ЗАКАЗ №1234</strong>, Древесина</h2>
      <p class="unloading-current-task-p">Получатель:</p>
      <p class="unloading-current-task-p-small">ООО "ЗСМ"</p>
      <p class="unloading-current-task-p">Срок:</p>
      <p class="unloading-current-task-p-small">17.04.2020</p>
      <p class="unloading-current-task-p">Адрес:</p>
      <p class="unloading-current-task-p-small">г. Казань, ул. Ленина д. 19 корп. 1</p>
      <p class="unloading-current-task-p">Контакты: Иванов Иван Иванович</p>
      <p class="unloading-current-task-p-small">Тел: +7(920)452-01-04</p>
      <button class="button-phone-icon"> <img src="../assets/phone.png" alt="phone"> </button>

      <p class="unloading-current-task-p">Дополнительно:  </p>
      <p class="unloading-current-task-p-small">Необходимо получить пропуск для въезда на территорию</p>
    </div>

    <div class="unloading-current-task-btns">
      <button class="unloading-current-task-button">Ожидание в очереди</button>
      <button class="unloading-current-task-button unloading-current-task-button-accent">Начало погрузки</button>
    </div>

    <div class="footer">
      <ul class="footer-nav">
        <li class="footer-nav-li"> <img src="../assets/chat.png" alt=""> Чат</li>
        <li class="footer-nav-li"> <img src="../assets/home.png" alt="">Главная</li>
        <li class="footer-nav-li"> <img src="../assets/navigation.png" alt="">Навигация</li>
      </ul>
    </div>


</div>
</template>
