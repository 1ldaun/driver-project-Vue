<template>

  <section class="sended">
    <p class="sended-p">
      Отправлено!
    </p>
    <img src="../assets/arrow.png" alt="" class="sended-img">
    <button class="sended-button">Начать выполнение заказа</button>
  </section>

</template>
