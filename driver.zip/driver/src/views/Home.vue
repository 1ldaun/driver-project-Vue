<template>
  <div class="home">

    <div class="header">
      <img class="header-logo" src="../assets/logo.jpg" alt="">
      <h1 class="header-h1">Маршрут:</h1>
    </div>

    <div class="order">
      <h2 class="order-h2">ЗАКАЗ №1234</h2>
      <div class="order-subtitle">
        <p class="order-p"><strong class="order-p-strong">Контрагент: ООО «Савушкин и Ко»</strong></p>
        <p class="order-p">Маршрут :  Москва – Казань</p>
        <p class="order-p">16.04 – 17.04</p>
      </div>
    </div>

    <div class="order">
      <h2 class="order-h2">ЗАКАЗ №1234</h2>
      <div class="order-subtitle">
        <p class="order-p"><strong class="order-p-strong">Контрагент: ООО «Савушкин и Ко»</strong></p>
        <p class="order-p">Маршрут :  Москва – Казань</p>
        <p class="order-p">16.04 – 17.04</p>
      </div>
    </div>

    <div class="order">
      <h2 class="order-h2">ЗАКАЗ №1234</h2>
      <div class="order-subtitle">
        <p class="order-p"><strong class="order-p-strong">Контрагент: ООО «Савушкин и Ко»</strong></p>
        <p class="order-p">Маршрут :  Москва – Казань</p>
        <p class="order-p">16.04 – 17.04</p>
      </div>
    </div>

    <div class="order">
      <h2 class="order-h2">ТО</h2>
      <div class="order-subtitle">
        <p class="order-p"><strong class="order-p-strong">Плановое ТО</strong></p>
        <p class="order-p">Маршрут :  Уфа</p>
        <p class="order-p">18.04 12:00</p>
      </div>
    </div>

    <div class="footer">
      <ul class="footer-nav">
        <li class="footer-nav-li"> <img src="../assets/chat.png" alt=""> Чат</li>
        <li class="footer-nav-li"> <img src="../assets/home.png" alt="">Главная</li>
        <li class="footer-nav-li"> <img src="../assets/navigation.png" alt="">Навигация</li>
      </ul>
    </div>

  </div>
</template>

<script>
export default {
  name: 'home'
}
</script>
