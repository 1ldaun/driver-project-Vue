<template>
<div class="shipping">
  <div class="header">
    <img class="header-logo" src="../assets/logo.jpg" alt="">
    <h1 class="header-h1">ТЕКУЩАЯ ЗАДАЧА:</h1>
  </div>

    <div>
      <h2 class="shipping-h2">Погрузка</h2>
      <p class="shipping-p">Контрагент: ООО «Савушкин и Ко»</p>
      <p class="shipping-p">Адрес: Москва, ул. Народного ополчения д. 20</p>
      <p class="shipping-p">Срок: 16.04 09:00 – 18:00</p>
      <p class="shipping-p">Дополнительно: Необходимо получить пропуск для въезда на территорию</p>
      <p class="shipping-p">Контакты: Иванов Иван Иванович</p>
      <p class="shipping-p">Тел: +7(920)452-01-04</p>
      <button class="button-phone-icon"> <img src="../assets/phone.png" alt="phone"> </button>
    </div>

    <div class="shipping-btns">
      <button class="shipping-button">Ожидание в очереди</button>
      <button class="shipping-button shipping-button-accent">Начало погрузки</button>
    </div>

    <div class="footer">
      <ul class="footer-nav">
        <li class="footer-nav-li"> <img src="../assets/chat.png" alt=""> Чат</li>
        <li class="footer-nav-li"> <img src="../assets/home.png" alt="">Главная</li>
        <li class="footer-nav-li"> <img src="../assets/navigation.png" alt="">Навигация</li>
      </ul>
    </div>


</div>
</template>
