<template>

    <section class="comment-shipping">

      <div class="shipping-comment">
        <p class="shipping-comment-p">
          Комментарий:
        </p>
        <textarea class="shipping-comment-textarea" align="top"> </textarea>
      </div>

      <div class="shipping-btns">
        <p class="unloading-comment-p">
          Сделать фото ТТН обязательно!
        </p>
        <button class="shipping-button shipping-button-accent comment-shipping-button">Сделать фото</button>
      </div>
    </section>
</template>
