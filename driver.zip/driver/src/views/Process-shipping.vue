<template>
  <div class="queue-shipping">
    <div class="waiting">
      <h3 class="waiting-h3">Погрузка</h3>
      <h3 class="waiting-h3">3:10</h3>
    </div>

    <div class="waiting-button">
      <h3 class="waiting-h3 expect">После окончания погрузки нажмите на кнопку и укажите тоннаж</h3>
        <img src="../assets/arrow.png" alt="" class="queue-shipping-sended-img">
      <button class="shipping-button shipping-button-accent">Погрузка завершена</button>
    </div>

      <div class="footer">
        <ul class="footer-nav">
          <li class="footer-nav-li"> <img src="../assets/chat.png" alt="">Чат</li>
          <li class="footer-nav-li"> <img src="../assets/home.png" alt="">Главная</li>
          <li class="footer-nav-li"> <img src="../assets/navigation.png" alt="">Навигация</li>
        </ul>
      </div>

  </div>
</template>
