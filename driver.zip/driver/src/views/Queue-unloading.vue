<template>
  <div class="queue-shipping">
    <div class="waiting">
      <h3 class="waiting-h3">Ожидание в очереди</h3>
      <h3 class="waiting-h3">0:20</h3>
    </div>

    <div class="waiting-button">
      <h3 class="waiting-h3 expect">Перед началом выгрузки нажмите на кнопку</h3>
        <img src="../assets/arrow.png" alt="" class="queue-shipping-sended-img">
      <button class="shipping-button shipping-button-accent">Начало погрузки</button>
    </div>

      <div class="footer">
        <ul class="footer-nav">
          <li class="footer-nav-li"> <img src="../assets/chat.png" alt="">Чат</li>
          <li class="footer-nav-li"> <img src="../assets/home.png" alt="">Главная</li>
          <li class="footer-nav-li"> <img src="../assets/navigation.png" alt="">Навигация</li>
        </ul>
      </div>

  </div>
</template>
