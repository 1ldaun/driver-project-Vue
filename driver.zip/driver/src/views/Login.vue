<template>
<div class="page">
  <form class="card auth-card">
    <div class="card-content">
      <span class="card-title">Введите 4-х значный код</span>
      <div class="input-field">
        <input id="password" type="password" class="validate">
      </div>
    </div>
    <div class="card-sms">
    <!--    <button class="btn waves-effect waves-light auth-submit" type="submit">
          Войти
          <i class="material-icons right">send</i>
        </button> -->
        <p class="center">
          <a class="card-sms-a" href="/">Направить код в СМС</a>
        </p>
    </div>
  </form>
</div>
</template>
