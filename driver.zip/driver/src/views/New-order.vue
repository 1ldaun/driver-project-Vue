<template>
  <div>

    <section class="new-order">
      <h2 class="new-order-h2">Вам назначен новый заказ!</h2>
      <div class="new-order-btns">
        <a href="#" class="new-order-a"><button class="new-order-a-btn">Карточка заказа</button></a>
        <a href="#" class="new-order-a"><button class="new-order-a-btn">ОК</button></a>
      </div>
    </section>
  </div>
</template>
