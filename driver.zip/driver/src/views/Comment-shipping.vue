<template>

    <section class="comment-shipping">
      <p class="shipping-ton-p">
        Тоннаж: <input type="text" class="shipping-ton-input" /> тонн
      </p>

      <div class="shipping-comment">
        <p class="shipping-comment-p">
          Комментарий:
        </p>
        <textarea class="shipping-comment-textarea" align="top"> </textarea>
      </div>

      <div class="shipping-btns">
        <button class="shipping-button shipping-button-accent comment-shipping-button">Сделать фото</button>
        <button class="shipping-button shipping-button-accent comment-shipping-button">Отправить</button>
      </div>
    </section>
</template>
