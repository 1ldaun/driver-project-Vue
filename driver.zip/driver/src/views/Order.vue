<template>
<div>
  <div class="header">
    <img class="header-logo" src="../assets/logo.jpg" alt="">
    <h1 class="header-h1">ЗАКАЗ №1234</h1>
  </div>
  <section class="current-task">
    <div class="client">
      <p class="client-p"><strong class="client-p-strong">Контрагент: ООО «Савушкин и Ко»</strong></p>
      <p class="client-p">Адрес погрузки: г. Москва, ул. Народного ополчения д. 20 стр. 1</p>
      <p class="client-p">Маршрут : Москва – Казань</p>
      <div class="client-time">
        <p class="client-data-p">16.04 – 17.04</p>
        <p class="client-time-p">09:00 - 18:00</p>
      </div>
      <p class="client-extra">Дополнительно: Необходимо получить пропуск для въезда на территорию</p>
      <p class="client-contact">Контакты: Иванов Иван Иванович</p>
      <p class="client-phone">Тел: +7(920)452-01-04</p>
      <button class="button-phone-icon"> <img src="../assets/phone.png" alt="phone"> </button>
    </div>

    <div class="recipient">
      <p class="recipient-p"><strong class="recipient-p-strong">Контрагент: ООО «Савушкин и Ко»</strong></p>
      <p class="recipient-p">Адрес погрузки: г. Москва, ул. Народного ополчения д. 20 стр. 1</p>
      <p class="recipient-p">Маршрут : Москва – Казань</p>
      <div class="recipient-time">
        <p class="recipient-data-p">16.04 – 17.04</p>
        <p class="recipient-time-p">09:00 - 18:00</p>
      </div>
      <p class="recipient-contact">Контакты: Иванов Иван Иванович</p>
      <p class="recipient-phone">Тел: +7(920)452-01-04</p>
      <button class="button-phone-icon"> <img src="../assets/phone.png" alt="phone"> </button>
    </div>

    <div class="footer">
      <ul class="footer-nav">
        <li class="footer-nav-li"> <img src="../assets/chat.png" alt=""> Чат</li>
        <li class="footer-nav-li"> <img src="../assets/home.png" alt="">Главная</li>
        <li class="footer-nav-li"> <img src="../assets/navigation.png" alt="">Навигация</li>
      </ul>
    </div>

  </section>
</div>
</template>
