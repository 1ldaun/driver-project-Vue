<template>

    <section class="comment-shipping">

      <div class="shipping-comment">
        <p class="shipping-comment-p">
          Фото ТТН:
        </p>
        <img src="../assets/ttn.png" class="unloading-img" />
      </div>

      <div class="shipping-btns">
        <button class="shipping-button shipping-button-accent comment-shipping-button">Отправить</button>
      </div>
    </section>
</template>
